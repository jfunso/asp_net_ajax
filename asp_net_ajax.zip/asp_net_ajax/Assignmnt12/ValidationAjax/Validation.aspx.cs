﻿
using System;

public partial class Validation : System.Web.UI.Page
{

   protected void Page_Load( object sender, EventArgs e )
   
{

      if ( IsPostBack )
      {
         Validate(); 

         // if the form is valid
         if ( IsValid )
         {
            // retrieve the values submitted by the user
            string name = nameTextBox.Text;
	    string lname = lnameTextBox.Text;
            string email = emailTextBox.Text;
            string phone = phoneTextBox.Text;
	    string subject = subjectTextBox.Text;
	    string category = categoryDropDownList.Text;
	    string message = messageTextBox.Text;
	    string HowDidYouGetToKnowUs = HowDidYouGetToKnowUsDropDownList.Text;
	    string rateoursite = rateoursiteDropDownList.Text;

            // show the submitted values
            outputLabel.Text = "Thank you for your submission<br/>" +
               "We received the following information:<br/>";
            outputLabel.Text +=
 String.Format("First Name: {0}{1}Last Name: {2}{1}E-mail: {4}{3}Phone: {6}{1}Subject: {8}{1}Category: {10}{1}Message: {12}{1}How did you get to know us: {14}{1}Rate our site: {16}{1}",
                      name, "<br/>", lname, "<br/>", email, "<br/>", phone, "<br/>", subject, "<br/>", category, "<br/>", message, "<br/>", HowDidYouGetToKnowUs, "<br/>", rateoursite, "<br/>");
            outputLabel.Visible = true; 
         } 
      } 
   } 
} 

 